import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        base: "#0A0A0F",
        surface: "#0F0F1A",
        card: "#121220",
        kawaii: {
          pink: "#FFB3D1",
          peach: "#FFCBA4",
          blue: "#B8D4FF",
          mint: "#B8F0DF",
          lavender: "#D4B8FF",
          yellow: "#FFF3B0",
        },
      },
      fontFamily: {
        display: ["var(--font-display)", "sans-serif"],
        body: ["var(--font-body)", "sans-serif"],
      },
      boxShadow: {
        "neo-pink": "4px 4px 0px rgba(255, 179, 209, 0.6)",
        "neo-blue": "4px 4px 0px rgba(184, 212, 255, 0.6)",
        "neo-peach": "4px 4px 0px rgba(255, 203, 164, 0.6)",
        "neo-lavender": "4px 4px 0px rgba(212, 184, 255, 0.6)",
        "neo-mint": "4px 4px 0px rgba(184, 240, 223, 0.6)",
      },
      keyframes: {
        float: {
          "0%, 100%": { transform: "translateY(0px) rotate(0deg)" },
          "50%": { transform: "translateY(-18px) rotate(8deg)" },
        },
        "float-r": {
          "0%, 100%": { transform: "translateY(0px) rotate(0deg)" },
          "50%": { transform: "translateY(18px) rotate(-8deg)" },
        },
        sparkle: {
          "0%, 100%": { opacity: "0.2", transform: "scale(0.8)" },
          "50%": { opacity: "1", transform: "scale(1.2)" },
        },
        "pulse-soft": {
          "0%, 100%": { opacity: "0.6" },
          "50%": { opacity: "1" },
        },
      },
      animation: {
        float: "float 5s ease-in-out infinite",
        "float-r": "float-r 6s ease-in-out infinite",
        "float-slow": "float 8s ease-in-out infinite",
        sparkle: "sparkle 2.5s ease-in-out infinite",
        "sparkle-delay": "sparkle 3s ease-in-out 1.2s infinite",
        "pulse-soft": "pulse-soft 3s ease-in-out infinite",
      },
    },
  },
  plugins: [],
};

export default config;
