"use client";

import { useRef, useEffect, useState } from "react";
import { motion, useInView } from "framer-motion";
import { Clock, FolderCheck, Zap, Coffee } from "lucide-react";

interface StatItem {
  icon: React.ElementType;
  value: number;
  suffix: string;
  label: string;
  color: string;
  border: string;
  shadow: string;
}

const stats: StatItem[] = [
  {
    icon: Clock,
    value: 3,
    suffix: "+ yrs",
    label: "Experience",
    color: "text-kawaii-pink",
    border: "border-kawaii-pink/60",
    shadow: "shadow-neo-pink",
  },
  {
    icon: FolderCheck,
    value: 50,
    suffix: "+",
    label: "Projects Completed",
    color: "text-kawaii-blue",
    border: "border-kawaii-blue/60",
    shadow: "shadow-neo-blue",
  },
  {
    icon: Zap,
    value: 12,
    suffix: "+",
    label: "Active Services",
    color: "text-kawaii-mint",
    border: "border-kawaii-mint/60",
    shadow: "shadow-neo-mint",
  },
  {
    icon: Coffee,
    value: 999,
    suffix: "+",
    label: "Coffee Level",
    color: "text-kawaii-peach",
    border: "border-kawaii-peach/60",
    shadow: "shadow-neo-peach",
  },
];

// Decorative background elements
const bgDecos = [
  { symbol: "★", x: "5%", y: "10%", size: "text-4xl", opacity: "opacity-[0.04]", cls: "animate-float-slow" },
  { symbol: "♡", x: "92%", y: "8%", size: "text-5xl", opacity: "opacity-[0.04]", cls: "animate-float-r" },
  { symbol: "✿", x: "50%", y: "5%", size: "text-3xl", opacity: "opacity-[0.05]", cls: "animate-float" },
  { symbol: "⋆", x: "15%", y: "85%", size: "text-5xl", opacity: "opacity-[0.04]", cls: "animate-sparkle" },
  { symbol: "✦", x: "80%", y: "80%", size: "text-4xl", opacity: "opacity-[0.05]", cls: "animate-sparkle-delay" },
  { symbol: "ꕥ", x: "30%", y: "90%", size: "text-3xl", opacity: "opacity-[0.04]", cls: "animate-float-r" },
  { symbol: "♡", x: "70%", y: "50%", size: "text-6xl", opacity: "opacity-[0.03]", cls: "animate-float-slow" },
];

function Counter({ value, suffix, inView }: { value: number; suffix: string; inView: boolean }) {
  const [count, setCount] = useState(0);

  useEffect(() => {
    if (!inView) return;
    const duration = 1800;
    const steps = 60;
    const increment = value / steps;
    let current = 0;
    let step = 0;

    const timer = setInterval(() => {
      step++;
      // Ease out
      const progress = step / steps;
      const easedProgress = 1 - Math.pow(1 - progress, 3);
      current = easedProgress * value;
      setCount(Math.min(Math.floor(current), value));
      if (step >= steps) {
        clearInterval(timer);
        setCount(value);
      }
    }, duration / steps);

    return () => clearInterval(timer);
  }, [inView, value]);

  return (
    <span>
      {count.toLocaleString()}
      {suffix}
    </span>
  );
}

const fadeUp = {
  hidden: { opacity: 0, y: 30 },
  visible: (i: number) => ({
    opacity: 1,
    y: 0,
    transition: { duration: 0.6, delay: i * 0.12, ease: [0.22, 1, 0.36, 1] },
  }),
};

export default function StatsSection() {
  const ref = useRef<HTMLElement>(null);
  const inView = useInView(ref, { once: true, margin: "-80px" });

  return (
    <section
      id="stats"
      ref={ref}
      className="relative py-24 px-4 overflow-hidden pattern-kawaii"
    >
      {/* Background decorative symbols */}
      {bgDecos.map((d, i) => (
        <span
          key={i}
          className={`absolute ${d.size} ${d.opacity} text-kawaii-pink select-none pointer-events-none ${d.cls}`}
          style={{ left: d.x, top: d.y }}
          aria-hidden="true"
        >
          {d.symbol}
        </span>
      ))}

      {/* Glow */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-[500px] h-[500px] bg-kawaii-lavender/4 blur-[150px] rounded-full" />
        <div className="absolute bottom-1/4 right-1/4 w-[400px] h-[400px] bg-kawaii-pink/4 blur-[120px] rounded-full" />
      </div>

      <div className="max-w-6xl mx-auto relative z-10">
        {/* Section label */}
        <motion.div
          custom={0} variants={fadeUp} initial="hidden" animate={inView ? "visible" : "hidden"}
          className="flex items-center gap-3 mb-12"
        >
          <span className="text-kawaii-lavender text-sm font-display font-semibold tracking-widest uppercase">
            05 / Developer Stats
          </span>
          <div className="flex-1 h-px bg-kawaii-lavender/20" />
        </motion.div>

        <motion.div
          custom={1} variants={fadeUp} initial="hidden" animate={inView ? "visible" : "hidden"}
          className="mb-12"
        >
          <h2 className="section-title text-white mb-3">
            By the <span className="gradient-pink">Numbers</span>
          </h2>
          <p className="text-white/50 font-body">
            Setiap angka mewakili sebuah cerita, pengalaman, dan dedikasi. ✦
          </p>
        </motion.div>

        {/* Stats grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-16">
          {stats.map((s, i) => (
            <motion.div
              key={s.label}
              custom={i + 2}
              variants={fadeUp}
              initial="hidden"
              animate={inView ? "visible" : "hidden"}
              whileHover={{ x: -2, y: -2, transition: { duration: 0.15 } }}
              className={`bg-[#0F0F1A] border-2 ${s.border} ${s.shadow} p-5 flex flex-col items-start gap-3 transition-shadow duration-200 hover:shadow-[6px_6px_0px_rgba(255,179,209,0.5)]`}
            >
              <div className={`p-2 bg-white/4 border border-white/8`}>
                <s.icon className={`w-5 h-5 ${s.color}`} />
              </div>
              <div>
                <div className={`font-display font-black text-3xl md:text-4xl ${s.color} leading-none`}>
                  <Counter value={s.value} suffix={s.suffix} inView={inView} />
                </div>
                <p className="text-white/50 text-sm font-body mt-1.5">{s.label}</p>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Quote */}
        <motion.div
          custom={6}
          variants={fadeUp}
          initial="hidden"
          animate={inView ? "visible" : "hidden"}
          className="relative"
        >
          <div className="neo-card-lavender p-8 md:p-10 text-center relative overflow-hidden">
            {/* Decorative quotes */}
            <span className="absolute top-4 left-6 text-6xl text-kawaii-lavender/15 font-display font-black leading-none select-none">
              «
            </span>
            <span className="absolute bottom-4 right-6 text-6xl text-kawaii-lavender/15 font-display font-black leading-none select-none">
              »
            </span>

            <div className="relative z-10">
              <span className="text-kawaii-pink text-lg animate-sparkle">★</span>
              <p className="font-display font-bold text-xl md:text-2xl lg:text-3xl text-white/90 mt-3 mb-3 leading-snug">
                «<span className="gradient-pink"> Code is magic written with logic. </span>»
              </p>
              <span className="text-kawaii-blue text-lg animate-sparkle-delay">★</span>
              <p className="text-white/35 font-body text-sm mt-4 tracking-widest uppercase">
                — Yue Sakibara, Developer & Creator
              </p>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
