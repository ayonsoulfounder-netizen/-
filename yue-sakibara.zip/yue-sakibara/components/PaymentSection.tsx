"use client";

import { useRef, useState } from "react";
import { motion, useInView } from "framer-motion";
import { Copy, Check, QrCode, Coffee, Heart } from "lucide-react";
import QRISModal from "./QRISModal";

const DANA_NUMBER = "0821-8112-9767";

const fadeUp = {
  hidden: { opacity: 0, y: 30 },
  visible: (i: number) => ({
    opacity: 1,
    y: 0,
    transition: { duration: 0.6, delay: i * 0.12, ease: [0.22, 1, 0.36, 1] },
  }),
};

export default function PaymentSection() {
  const ref = useRef<HTMLElement>(null);
  const inView = useInView(ref, { once: true, margin: "-80px" });
  const [copied, setCopied] = useState(false);
  const [qrisOpen, setQrisOpen] = useState(false);

  const copyDana = async () => {
    try {
      await navigator.clipboard.writeText(DANA_NUMBER.replace(/-/g, ""));
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    } catch {
      // fallback: select text
      const el = document.createElement("textarea");
      el.value = DANA_NUMBER;
      document.body.appendChild(el);
      el.select();
      document.execCommand("copy");
      document.body.removeChild(el);
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    }
  };

  return (
    <section id="payment" ref={ref} className="relative py-24 px-4 overflow-hidden">
      {/* Glow */}
      <div className="absolute top-1/2 right-1/4 w-[350px] h-[350px] bg-kawaii-peach/5 blur-[120px] pointer-events-none" />

      <div className="max-w-6xl mx-auto">
        {/* Section label */}
        <motion.div
          custom={0} variants={fadeUp} initial="hidden" animate={inView ? "visible" : "hidden"}
          className="flex items-center gap-3 mb-12"
        >
          <span className="text-kawaii-peach text-sm font-display font-semibold tracking-widest uppercase">
            04 / Support Me
          </span>
          <div className="flex-1 h-px bg-kawaii-peach/20" />
        </motion.div>

        <motion.div
          custom={1} variants={fadeUp} initial="hidden" animate={inView ? "visible" : "hidden"}
          className="mb-10"
        >
          <h2 className="section-title text-white mb-3 flex items-center gap-3">
            <Coffee className="w-8 h-8 text-kawaii-peach" />
            Support My Projects
          </h2>
          <p className="text-white/55 font-body max-w-xl leading-relaxed">
            Jika ingin traktir kopi atau mendukung project saya, kamu bisa menggunakan metode
            pembayaran berikut. Setiap dukungan sangat berarti bagi saya ♡
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-2xl">
          {/* Dana card */}
          <motion.div
            custom={2} variants={fadeUp} initial="hidden" animate={inView ? "visible" : "hidden"}
            className="neo-card-peach p-6 flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center gap-3 mb-5">
                <div className="w-10 h-10 flex items-center justify-center bg-kawaii-peach/15 border border-kawaii-peach/40">
                  <span className="text-xl font-display font-black text-kawaii-peach">D</span>
                </div>
                <div>
                  <p className="font-display font-bold text-white">Dana</p>
                  <p className="text-xs text-white/40 font-body">Dompet Digital</p>
                </div>
              </div>

              <div className="p-3 bg-white/4 border border-kawaii-peach/20 mb-4">
                <p className="text-xs text-white/40 font-body mb-1">Nomor Dana</p>
                <p className="font-display font-bold text-kawaii-peach text-xl tracking-widest">
                  {DANA_NUMBER}
                </p>
              </div>
            </div>

            <motion.button
              onClick={copyDana}
              whileHover={{ scale: 1.02, y: -2 }}
              whileTap={{ scale: 0.97 }}
              className="w-full flex items-center justify-center gap-2 py-3 border-2 border-kawaii-peach text-kawaii-peach font-display font-bold text-sm shadow-neo-peach hover:bg-kawaii-peach/10 hover:translate-x-[-2px] hover:translate-y-[-2px] hover:shadow-[6px_6px_0px_rgba(255,203,164,0.6)] transition-all duration-150"
            >
              {copied ? (
                <>
                  <Check className="w-4 h-4" />
                  Copied!
                </>
              ) : (
                <>
                  <Copy className="w-4 h-4" />
                  Copy Dana Number
                </>
              )}
            </motion.button>
          </motion.div>

          {/* QRIS card */}
          <motion.div
            custom={3} variants={fadeUp} initial="hidden" animate={inView ? "visible" : "hidden"}
            className="neo-card-pink p-6 flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center gap-3 mb-5">
                <div className="w-10 h-10 flex items-center justify-center bg-kawaii-pink/15 border border-kawaii-pink/40">
                  <QrCode className="w-5 h-5 text-kawaii-pink" />
                </div>
                <div>
                  <p className="font-display font-bold text-white">QRIS</p>
                  <p className="text-xs text-white/40 font-body">Scan & Pay</p>
                </div>
              </div>

              <div className="p-4 bg-white/4 border border-kawaii-pink/20 mb-4 flex flex-col items-center gap-2">
                <QrCode className="w-12 h-12 text-kawaii-pink/50" />
                <p className="text-white/50 text-sm font-body text-center">
                  Yonz Market — SATU QRIS UNTUK SEMUA
                </p>
                <p className="text-white/30 text-xs font-body">
                  Semua e-wallet & m-banking didukung
                </p>
              </div>
            </div>

            <motion.button
              onClick={() => setQrisOpen(true)}
              whileHover={{ scale: 1.02, y: -2 }}
              whileTap={{ scale: 0.97 }}
              className="w-full flex items-center justify-center gap-2 py-3 bg-kawaii-pink text-black font-display font-bold text-sm border-2 border-kawaii-pink shadow-[4px_4px_0px_rgba(0,0,0,0.4)] hover:translate-x-[-2px] hover:translate-y-[-2px] hover:shadow-[6px_6px_0px_rgba(0,0,0,0.5)] transition-all duration-150"
            >
              <QrCode className="w-4 h-4" />
              Preview QRIS
            </motion.button>
          </motion.div>
        </div>

        {/* Thank you note */}
        <motion.div
          custom={4} variants={fadeUp} initial="hidden" animate={inView ? "visible" : "hidden"}
          className="mt-8 flex items-center gap-2 text-white/30 text-sm font-body"
        >
          <Heart className="w-4 h-4 text-kawaii-pink animate-pulse-soft" />
          <span>Terima kasih atas dukunganmu. Itu sangat berarti bagi saya!</span>
        </motion.div>
      </div>

      {/* QRIS Modal */}
      <QRISModal isOpen={qrisOpen} onClose={() => setQrisOpen(false)} />
    </section>
  );
}
