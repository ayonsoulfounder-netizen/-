"use client";

import { motion } from "framer-motion";
import { Sparkles, Heart } from "lucide-react";

const quickLinks = [
  { label: "About", href: "#about" },
  { label: "Services", href: "#services" },
  { label: "Social", href: "#social" },
  { label: "Payment", href: "#payment" },
];

const socialLinks = [
  { label: "Telegram", href: "https://t.me/yueech" },
  { label: "TikTok", href: "https://tiktok.com/@huntlevdown" },
  { label: "YouTube", href: "https://youtube.com/@yonz_education" },
  { label: "WhatsApp", href: "https://wa.me/6285141783810" },
];

export default function Footer() {
  const scrollTo = (href: string) => {
    document.querySelector(href)?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <footer className="relative border-t border-kawaii-pink/15 bg-[#080810] overflow-hidden">
      {/* Subtle glow */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[600px] h-px bg-gradient-to-r from-transparent via-kawaii-pink/30 to-transparent" />

      <div className="max-w-6xl mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-10">
          {/* Brand */}
          <div>
            <div className="flex items-center gap-2 mb-3">
              <Sparkles className="w-4 h-4 text-kawaii-pink" />
              <span className="font-display font-bold text-xl text-white">
                Yue<span className="text-kawaii-pink">.</span>
              </span>
            </div>
            <p className="text-white/40 font-body text-sm leading-relaxed">
              Developer, Designer & Creator. Building beautiful digital experiences with passion and precision.
            </p>
            <div className="mt-4 flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-kawaii-mint animate-pulse-soft" />
              <span className="text-kawaii-mint text-xs font-body">Available for projects</span>
            </div>
          </div>

          {/* Quick links */}
          <div>
            <p className="font-display font-semibold text-white/60 text-xs tracking-widest uppercase mb-4">
              Navigation
            </p>
            <ul className="space-y-2">
              {quickLinks.map((link) => (
                <li key={link.href}>
                  <button
                    onClick={() => scrollTo(link.href)}
                    className="text-white/40 hover:text-kawaii-pink font-body text-sm transition-colors duration-200 hover:translate-x-1 inline-block"
                  >
                    {link.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Social links */}
          <div>
            <p className="font-display font-semibold text-white/60 text-xs tracking-widest uppercase mb-4">
              Find Me
            </p>
            <ul className="space-y-2">
              {socialLinks.map((link) => (
                <li key={link.label}>
                  <a
                    href={link.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-white/40 hover:text-kawaii-blue font-body text-sm transition-colors duration-200"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="border-t border-white/6 pt-6 flex flex-col sm:flex-row items-center justify-between gap-3">
          <motion.p
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            className="text-white/30 text-sm font-body text-center sm:text-left"
          >
            © 2026 Yue Sakibara. Crafted with{" "}
            <span className="text-kawaii-pink font-semibold">Neo-Brutalism</span> &{" "}
            <span className="text-kawaii-blue font-semibold">Anime Aesthetics</span>.
          </motion.p>

          <div className="flex items-center gap-1.5 text-white/20 text-xs font-body">
            <span>Made with</span>
            <Heart className="w-3 h-3 text-kawaii-pink fill-kawaii-pink animate-pulse-soft" />
            <span>in Indonesia</span>
          </div>
        </div>
      </div>

      {/* Bottom decoration */}
      <div className="h-1 bg-gradient-to-r from-kawaii-pink/50 via-kawaii-lavender/50 to-kawaii-blue/50" />
    </footer>
  );
}
