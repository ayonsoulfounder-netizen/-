"use client";

import { useRef } from "react";
import { motion, useInView } from "framer-motion";
import Image from "next/image";
import { Code2, Cpu, Globe, Server } from "lucide-react";

const skills = [
  { label: "Next.js", color: "pink" },
  { label: "React", color: "blue" },
  { label: "TypeScript", color: "blue" },
  { label: "Tailwind CSS", color: "mint" },
  { label: "UI/UX Design", color: "pink" },
  { label: "API Integration", color: "lavender" },
  { label: "Vercel Deployment", color: "peach" },
  { label: "Automation", color: "peach" },
  { label: "Pterodactyl", color: "mint" },
  { label: "Linux Server", color: "lavender" },
];

const badgeColors: Record<string, string> = {
  pink: "border-kawaii-pink/60 text-kawaii-pink bg-kawaii-pink/10 shadow-[3px_3px_0px_rgba(255,179,209,0.35)]",
  blue: "border-kawaii-blue/60 text-kawaii-blue bg-kawaii-blue/10 shadow-[3px_3px_0px_rgba(184,212,255,0.35)]",
  mint: "border-kawaii-mint/60 text-kawaii-mint bg-kawaii-mint/10 shadow-[3px_3px_0px_rgba(184,240,223,0.35)]",
  peach: "border-kawaii-peach/60 text-kawaii-peach bg-kawaii-peach/10 shadow-[3px_3px_0px_rgba(255,203,164,0.35)]",
  lavender: "border-kawaii-lavender/60 text-kawaii-lavender bg-kawaii-lavender/10 shadow-[3px_3px_0px_rgba(212,184,255,0.35)]",
};

const highlights = [
  { icon: Code2, label: "Web Development", color: "text-kawaii-pink" },
  { icon: Globe, label: "UI/UX & Design", color: "text-kawaii-blue" },
  { icon: Cpu, label: "Automation & Bots", color: "text-kawaii-mint" },
  { icon: Server, label: "Server Management", color: "text-kawaii-peach" },
];

const fadeUp = {
  hidden: { opacity: 0, y: 30 },
  visible: (i: number) => ({
    opacity: 1,
    y: 0,
    transition: { duration: 0.6, delay: i * 0.1, ease: [0.22, 1, 0.36, 1] },
  }),
};

export default function AboutSection() {
  const ref = useRef<HTMLElement>(null);
  const inView = useInView(ref, { once: true, margin: "-80px" });

  return (
    <section id="about" ref={ref} className="relative py-24 px-4 overflow-hidden">
      {/* Soft glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] rounded-full bg-kawaii-pink/5 blur-[120px] pointer-events-none" />

      <div className="max-w-6xl mx-auto">
        {/* Section label */}
        <motion.div
          custom={0}
          variants={fadeUp}
          initial="hidden"
          animate={inView ? "visible" : "hidden"}
          className="flex items-center gap-3 mb-12"
        >
          <span className="text-kawaii-pink text-sm font-display font-semibold tracking-widest uppercase">
            01 / About
          </span>
          <div className="flex-1 h-px bg-kawaii-pink/20" />
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          {/* Profile image + frame */}
          <motion.div
            custom={1}
            variants={fadeUp}
            initial="hidden"
            animate={inView ? "visible" : "hidden"}
            className="flex justify-center lg:justify-start"
          >
            <div className="relative">
              {/* Decorative offset frame */}
              <div className="absolute inset-0 border-2 border-kawaii-pink/50 translate-x-4 translate-y-4" />
              <div className="absolute inset-0 border border-kawaii-blue/30 -translate-x-3 -translate-y-3" />

              {/* Profile image */}
              <div className="relative w-64 h-64 md:w-80 md:h-80 border-2 border-kawaii-pink/70 overflow-hidden shadow-neo-pink">
                <Image
                  src="/profile.jpg"
                  alt="Yue Sakibara"
                  fill
                  className="object-cover"
                  priority
                />
                {/* Subtle pink gradient overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-[#0A0A0F]/40 via-transparent to-transparent" />
              </div>

              {/* Floating badge */}
              <motion.div
                animate={{ y: [0, -6, 0] }}
                transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
                className="absolute -bottom-4 -right-4 bg-[#0F0F1A] border-2 border-kawaii-peach/70 shadow-neo-peach px-3 py-2"
              >
                <p className="text-kawaii-peach text-xs font-display font-bold">✦ Developer</p>
              </motion.div>

              {/* Sparkle decorations */}
              <span className="absolute -top-3 -left-3 text-2xl text-kawaii-pink animate-sparkle">★</span>
              <span className="absolute top-1/4 -right-5 text-xl text-kawaii-blue animate-sparkle-delay">♡</span>
            </div>
          </motion.div>

          {/* Text content */}
          <div className="space-y-6">
            <motion.div
              custom={2}
              variants={fadeUp}
              initial="hidden"
              animate={inView ? "visible" : "hidden"}
            >
              <h2 className="font-display font-bold text-4xl md:text-5xl leading-tight mb-3">
                <span className="text-white/60 text-2xl block mb-1">⸸</span>
                <span className="gradient-pink">𝒀𝒖𝒆 𝑺𝒂𝒌𝒊𝒃𝒂𝒓𝒂</span>
                <span className="text-white/60 text-2xl block mt-1">⸸</span>
              </h2>
            </motion.div>

            <motion.p
              custom={3}
              variants={fadeUp}
              initial="hidden"
              animate={inView ? "visible" : "hidden"}
              className="text-white/65 font-body text-base leading-relaxed"
            >
              Seorang passionate developer yang mengkhususkan diri dalam membangun pengalaman digital
              yang indah, fungsional, dan berkesan. Dari web apps modern hingga sistem backend yang
              robust — setiap baris kode ditulis dengan presisi dan estetika.
            </motion.p>

            <motion.p
              custom={4}
              variants={fadeUp}
              initial="hidden"
              animate={inView ? "visible" : "hidden"}
              className="text-white/65 font-body text-base leading-relaxed"
            >
              Berfokus pada{" "}
              <span className="text-kawaii-pink font-semibold">web development</span>,{" "}
              <span className="text-kawaii-blue font-semibold">UI/UX design</span>,{" "}
              <span className="text-kawaii-mint font-semibold">automation</span>,{" "}
              <span className="text-kawaii-peach font-semibold">bot development</span>,{" "}
              <span className="text-kawaii-lavender font-semibold">server management</span>, dan
              pengembangan layanan digital modern yang siap pakai.
            </motion.p>

            {/* Highlights grid */}
            <motion.div
              custom={5}
              variants={fadeUp}
              initial="hidden"
              animate={inView ? "visible" : "hidden"}
              className="grid grid-cols-2 gap-3"
            >
              {highlights.map((h) => (
                <div
                  key={h.label}
                  className="flex items-center gap-2 py-2 px-3 bg-white/3 border border-white/8 hover:border-kawaii-pink/30 transition-colors"
                >
                  <h.icon className={`w-4 h-4 ${h.color} shrink-0`} />
                  <span className="text-sm text-white/70 font-body">{h.label}</span>
                </div>
              ))}
            </motion.div>

            {/* Skill badges */}
            <motion.div
              custom={6}
              variants={fadeUp}
              initial="hidden"
              animate={inView ? "visible" : "hidden"}
            >
              <p className="text-xs text-white/40 font-display font-semibold tracking-widest uppercase mb-3">
                Tech Stack
              </p>
              <div className="flex flex-wrap gap-2">
                {skills.map((skill) => (
                  <motion.span
                    key={skill.label}
                    whileHover={{ y: -2, scale: 1.04 }}
                    className={`px-3 py-1.5 text-xs font-display font-bold border-2 transition-transform cursor-default ${badgeColors[skill.color]}`}
                  >
                    {skill.label}
                  </motion.span>
                ))}
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  );
}
