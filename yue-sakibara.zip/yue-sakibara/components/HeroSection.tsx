"use client";

import { useRef } from "react";
import { motion } from "framer-motion";
import { ChevronDown, Send } from "lucide-react";

const floatingDeco = [
  { symbol: "♡", x: "10%", y: "20%", size: "text-2xl", delay: 0, cls: "animate-float" },
  { symbol: "★", x: "85%", y: "15%", size: "text-3xl", delay: 1, cls: "animate-float-r" },
  { symbol: "✿", x: "75%", y: "65%", size: "text-xl", delay: 0.5, cls: "animate-float" },
  { symbol: "♡", x: "5%", y: "70%", size: "text-xl", delay: 1.5, cls: "animate-float-r" },
  { symbol: "⋆", x: "90%", y: "50%", size: "text-4xl", delay: 0.8, cls: "animate-sparkle" },
  { symbol: "✦", x: "20%", y: "80%", size: "text-2xl", delay: 1.2, cls: "animate-sparkle-delay" },
  { symbol: "ꕥ", x: "50%", y: "12%", size: "text-xl", delay: 0.3, cls: "animate-float-slow" },
];

const container = {
  hidden: {},
  visible: { transition: { staggerChildren: 0.15, delayChildren: 0.4 } },
};

const item = {
  hidden: { opacity: 0, y: 40 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.7, ease: [0.22, 1, 0.36, 1] } },
};

export default function HeroSection() {
  const videoRef = useRef<HTMLVideoElement>(null);

  const scrollToAbout = () => {
    document.querySelector("#about")?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <section
      id="home"
      className="relative min-h-screen flex items-center justify-center overflow-hidden"
    >
      {/* Video background */}
      <div className="absolute inset-0 z-0">
        <video
          ref={videoRef}
          autoPlay
          muted
          loop
          playsInline
          className="w-full h-full object-cover"
          style={{ filter: "blur(2px) brightness(0.55)" }}
        >
          <source src="/hero.mp4" type="video/mp4" />
        </video>
      </div>

      {/* Gradient overlays */}
      <div className="absolute inset-0 z-[1] bg-gradient-to-b from-[#0A0A0F]/60 via-transparent to-[#0A0A0F]" />
      <div className="absolute inset-0 z-[1] bg-gradient-to-r from-[#0A0A0F]/50 via-transparent to-[#0A0A0F]/50" />

      {/* Decorative floating elements */}
      {floatingDeco.map((d, i) => (
        <span
          key={i}
          className={`absolute z-[2] ${d.size} text-kawaii-pink/40 select-none pointer-events-none ${d.cls}`}
          style={{ left: d.x, top: d.y }}
        >
          {d.symbol}
        </span>
      ))}

      {/* Content */}
      <motion.div
        variants={container}
        initial="hidden"
        animate="visible"
        className="relative z-[3] text-center px-4 max-w-4xl mx-auto"
      >
        {/* Badge */}
        <motion.div variants={item} className="flex justify-center mb-6">
          <span className="inline-flex items-center gap-2 px-4 py-1.5 border border-kawaii-pink/50 bg-kawaii-pink/10 text-kawaii-pink text-xs font-display font-semibold tracking-widest uppercase">
            <span className="w-1.5 h-1.5 rounded-full bg-kawaii-pink animate-pulse-soft" />
            Available for Projects
          </span>
        </motion.div>

        {/* Main title */}
        <motion.h1
          variants={item}
          className="font-display font-bold text-5xl sm:text-6xl md:text-7xl lg:text-8xl leading-none mb-4"
        >
          <span className="block text-white/90">⸸</span>
          <span className="block gradient-pink">𝒀𝒖𝒆 𝑺𝒂𝒌𝒊𝒃𝒂𝒓𝒂</span>
          <span className="block text-white/90">⸸</span>
        </motion.h1>

        {/* Subtitle */}
        <motion.p
          variants={item}
          className="text-base md:text-lg text-white/60 font-body tracking-widest uppercase mt-4 mb-8"
        >
          Developer&nbsp;
          <span className="text-kawaii-pink">•</span>
          &nbsp;Designer&nbsp;
          <span className="text-kawaii-blue">•</span>
          &nbsp;Creator
        </motion.p>

        {/* CTA buttons */}
        <motion.div
          variants={item}
          className="flex flex-wrap gap-4 justify-center"
        >
          <motion.button
            whileHover={{ scale: 1.04, y: -2 }}
            whileTap={{ scale: 0.97 }}
            onClick={scrollToAbout}
            className="btn-solid-pink flex items-center gap-2 text-sm"
          >
            <ChevronDown className="w-4 h-4" />
            Explore
          </motion.button>
          <motion.a
            href="https://t.me/yueech"
            target="_blank"
            rel="noopener noreferrer"
            whileHover={{ scale: 1.04, y: -2 }}
            whileTap={{ scale: 0.97 }}
            className="btn-pink flex items-center gap-2 text-sm"
          >
            <Send className="w-4 h-4" />
            Contact
          </motion.a>
        </motion.div>
      </motion.div>

      {/* Scroll indicator */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 2 }}
        className="absolute bottom-8 left-1/2 -translate-x-1/2 z-[3] flex flex-col items-center gap-2"
      >
        <span className="text-xs text-white/30 font-body tracking-widest uppercase">Scroll</span>
        <motion.div
          animate={{ y: [0, 8, 0] }}
          transition={{ duration: 1.5, repeat: Infinity, ease: "easeInOut" }}
          className="w-px h-8 bg-gradient-to-b from-kawaii-pink/60 to-transparent"
        />
      </motion.div>
    </section>
  );
}
