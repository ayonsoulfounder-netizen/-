"use client";

import { useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import Image from "next/image";
import { X, QrCode } from "lucide-react";

interface QRISModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function QRISModal({ isOpen, onClose }: QRISModalProps) {
  // Close on Escape key
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    if (isOpen) {
      window.addEventListener("keydown", onKey);
      document.body.style.overflow = "hidden";
    }
    return () => {
      window.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [isOpen, onClose]);

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            onClick={onClose}
            className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm"
          />

          {/* Modal */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 20 }}
            transition={{ duration: 0.3, ease: [0.22, 1, 0.36, 1] }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4"
            aria-modal="true"
            role="dialog"
          >
            <div className="relative bg-[#0F0F1A] border-2 border-kawaii-pink/70 shadow-[8px_8px_0px_rgba(255,179,209,0.5)] max-w-sm w-full max-h-[90vh] overflow-y-auto">
              {/* Header */}
              <div className="flex items-center justify-between p-4 border-b border-kawaii-pink/20">
                <div className="flex items-center gap-2">
                  <QrCode className="w-5 h-5 text-kawaii-pink" />
                  <span className="font-display font-bold text-white">QRIS Payment</span>
                </div>
                <motion.button
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.9 }}
                  onClick={onClose}
                  className="p-1.5 text-white/50 hover:text-kawaii-pink hover:bg-kawaii-pink/10 transition-colors"
                  aria-label="Close"
                >
                  <X className="w-5 h-5" />
                </motion.button>
              </div>

              {/* QRIS Image */}
              <div className="p-4">
                <div className="relative w-full aspect-[3/4] border border-kawaii-pink/30">
                  <Image
                    src="/qris.jpg"
                    alt="QRIS Payment - Yonz Market"
                    fill
                    className="object-contain"
                    priority
                  />
                </div>
                <div className="mt-4 p-3 bg-kawaii-pink/5 border border-kawaii-pink/20">
                  <p className="text-kawaii-pink font-display font-bold text-sm text-center">
                    Yonz Market
                  </p>
                  <p className="text-white/50 text-xs font-body text-center mt-1">
                    Scan QR code dengan aplikasi e-wallet apapun
                  </p>
                  <p className="text-white/40 text-xs font-body text-center mt-1">
                    SATU QRIS UNTUK SEMUA ✦
                  </p>
                </div>
              </div>

              {/* Footer */}
              <div className="px-4 pb-4">
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.97 }}
                  onClick={onClose}
                  className="w-full py-3 border-2 border-white/20 text-white/60 hover:border-kawaii-pink hover:text-kawaii-pink font-display font-semibold text-sm transition-all duration-200"
                >
                  Tutup
                </motion.button>
              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
