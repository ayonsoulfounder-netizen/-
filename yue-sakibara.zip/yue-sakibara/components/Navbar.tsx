"use client";

import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Menu, X, Sparkles, Mail } from "lucide-react";

const navLinks = [
  { label: "Home", href: "#home" },
  { label: "About", href: "#about" },
  { label: "Services", href: "#services" },
  { label: "Social", href: "#social" },
  { label: "Payment", href: "#payment" },
  { label: "Stats", href: "#stats" },
];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 60);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const handleNav = (href: string) => {
    setMenuOpen(false);
    const el = document.querySelector(href);
    if (el) el.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <>
      <motion.nav
        initial={{ y: -80, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.6, ease: "easeOut" }}
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          scrolled
            ? "bg-[#0A0A0F]/90 backdrop-blur-xl border-b border-kawaii-pink/20 shadow-[0_4px_30px_rgba(255,179,209,0.08)]"
            : "bg-transparent"
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <motion.button
              onClick={() => handleNav("#home")}
              className="flex items-center gap-2 group"
              whileHover={{ scale: 1.03 }}
            >
              <Sparkles className="w-4 h-4 text-kawaii-pink animate-sparkle" />
              <span className="font-display font-bold text-lg text-white group-hover:text-kawaii-pink transition-colors">
                Yue<span className="text-kawaii-pink">.</span>
              </span>
            </motion.button>

            {/* Desktop links */}
            <div className="hidden md:flex items-center gap-1">
              {navLinks.map((link) => (
                <button
                  key={link.href}
                  onClick={() => handleNav(link.href)}
                  className="px-4 py-2 text-sm font-body text-white/70 hover:text-kawaii-pink transition-colors duration-200 relative group"
                >
                  {link.label}
                  <span className="absolute bottom-1 left-1/2 -translate-x-1/2 w-0 h-px bg-kawaii-pink group-hover:w-3/4 transition-all duration-200" />
                </button>
              ))}
            </div>

            {/* CTA + hamburger */}
            <div className="flex items-center gap-3">
              <motion.a
                href="https://t.me/yueech"
                target="_blank"
                rel="noopener noreferrer"
                whileHover={{ scale: 1.05, y: -1 }}
                whileTap={{ scale: 0.97 }}
                className="hidden sm:flex items-center gap-2 px-4 py-2 text-sm font-display font-bold border-2 border-kawaii-pink text-kawaii-pink shadow-neo-pink hover:bg-kawaii-pink/10 transition-all duration-150"
              >
                <Mail className="w-3.5 h-3.5" />
                Contact Me
              </motion.a>

              <button
                onClick={() => setMenuOpen(!menuOpen)}
                className="md:hidden p-2 text-white/80 hover:text-kawaii-pink transition-colors"
                aria-label="Toggle menu"
              >
                {menuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
            </div>
          </div>
        </div>
      </motion.nav>

      {/* Mobile menu */}
      <AnimatePresence>
        {menuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.25 }}
            className="fixed top-16 left-0 right-0 z-40 bg-[#0A0A0F]/95 backdrop-blur-xl border-b-2 border-kawaii-pink/30 md:hidden"
          >
            <div className="px-4 py-4 flex flex-col gap-1">
              {navLinks.map((link, i) => (
                <motion.button
                  key={link.href}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.05 }}
                  onClick={() => handleNav(link.href)}
                  className="text-left px-4 py-3 text-white/80 hover:text-kawaii-pink hover:bg-kawaii-pink/5 transition-colors font-body text-base border-l-2 border-transparent hover:border-kawaii-pink"
                >
                  {link.label}
                </motion.button>
              ))}
              <a
                href="https://t.me/yueech"
                target="_blank"
                rel="noopener noreferrer"
                className="mt-2 mx-4 flex items-center justify-center gap-2 py-3 border-2 border-kawaii-pink text-kawaii-pink font-display font-bold text-sm shadow-neo-pink"
              >
                <Mail className="w-4 h-4" />
                Contact Me
              </a>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
