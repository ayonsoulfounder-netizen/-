"use client";

import { useRef } from "react";
import { motion, useInView } from "framer-motion";
import { Send, Phone, Youtube, ExternalLink, Music2 } from "lucide-react";

const socials = [
  {
    platform: "TikTok",
    handle: "@huntlevdown",
    href: "https://tiktok.com/@huntlevdown",
    icon: Music2,
    color: "pink",
    description: "Short videos & content creation",
    accent: "bg-kawaii-pink/10 border-kawaii-pink/60",
    shadow: "shadow-neo-pink",
    hoverShadow: "hover:shadow-[6px_6px_0px_rgba(255,179,209,0.7)]",
    textColor: "text-kawaii-pink",
  },
  {
    platform: "Telegram",
    handle: "@yueech",
    href: "https://t.me/yueech",
    icon: Send,
    color: "blue",
    description: "Direct messages & updates",
    accent: "bg-kawaii-blue/10 border-kawaii-blue/60",
    shadow: "shadow-neo-blue",
    hoverShadow: "hover:shadow-[6px_6px_0px_rgba(184,212,255,0.7)]",
    textColor: "text-kawaii-blue",
  },
  {
    platform: "WhatsApp",
    handle: "0851-4178-3810",
    href: "https://wa.me/6285141783810",
    icon: Phone,
    color: "mint",
    description: "Chat langsung & konsultasi",
    accent: "bg-kawaii-mint/10 border-kawaii-mint/60",
    shadow: "shadow-neo-mint",
    hoverShadow: "hover:shadow-[6px_6px_0px_rgba(184,240,223,0.7)]",
    textColor: "text-kawaii-mint",
  },
  {
    platform: "YouTube",
    handle: "@yonz_education",
    href: "https://youtube.com/@yonz_education?si=vBW-reVWnwqf-bIa",
    icon: Youtube,
    color: "peach",
    description: "Tutorials & educational content",
    accent: "bg-kawaii-peach/10 border-kawaii-peach/60",
    shadow: "shadow-neo-peach",
    hoverShadow: "hover:shadow-[6px_6px_0px_rgba(255,203,164,0.7)]",
    textColor: "text-kawaii-peach",
  },
];

const fadeUp = {
  hidden: { opacity: 0, y: 30 },
  visible: (i: number) => ({
    opacity: 1,
    y: 0,
    transition: { duration: 0.6, delay: i * 0.12, ease: [0.22, 1, 0.36, 1] },
  }),
};

export default function SocialSection() {
  const ref = useRef<HTMLElement>(null);
  const inView = useInView(ref, { once: true, margin: "-80px" });

  return (
    <section id="social" ref={ref} className="relative py-24 px-4 overflow-hidden">
      {/* Glow */}
      <div className="absolute bottom-1/4 left-0 w-[400px] h-[400px] bg-kawaii-lavender/5 blur-[120px] pointer-events-none" />

      <div className="max-w-6xl mx-auto">
        {/* Section label */}
        <motion.div
          custom={0} variants={fadeUp} initial="hidden" animate={inView ? "visible" : "hidden"}
          className="flex items-center gap-3 mb-12"
        >
          <span className="text-kawaii-lavender text-sm font-display font-semibold tracking-widest uppercase">
            03 / Social Media
          </span>
          <div className="flex-1 h-px bg-kawaii-lavender/20" />
        </motion.div>

        <motion.div
          custom={1} variants={fadeUp} initial="hidden" animate={inView ? "visible" : "hidden"}
          className="mb-10"
        >
          <h2 className="section-title text-white mb-3">
            Find Me <span className="gradient-pink">Online</span>
          </h2>
          <p className="text-white/50 font-body">
            Ikuti perjalanan kreatifku di berbagai platform. Semua link aktif dan siap dihubungi. ✦
          </p>
        </motion.div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
          {socials.map((s, i) => (
            <motion.a
              key={s.platform}
              href={s.href}
              target="_blank"
              rel="noopener noreferrer"
              custom={i + 2}
              variants={fadeUp}
              initial="hidden"
              animate={inView ? "visible" : "hidden"}
              whileHover={{ x: -3, y: -3 }}
              whileTap={{ x: 0, y: 0 }}
              className={`group block p-5 border-2 ${s.accent} ${s.shadow} ${s.hoverShadow} bg-[#0F0F1A] transition-all duration-200 cursor-pointer`}
            >
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className={`p-2.5 ${s.accent} border`}>
                    <s.icon className={`w-5 h-5 ${s.textColor}`} />
                  </div>
                  <div>
                    <p className="font-display font-bold text-white text-base">{s.platform}</p>
                    <p className={`text-sm font-body font-medium ${s.textColor}`}>{s.handle}</p>
                  </div>
                </div>
                <ExternalLink className={`w-4 h-4 ${s.textColor} opacity-0 group-hover:opacity-100 transition-opacity shrink-0 mt-1`} />
              </div>

              <p className="text-white/50 text-sm font-body">{s.description}</p>

              <div className={`mt-4 pt-3 border-t border-white/8 flex items-center gap-2`}>
                <span className={`text-xs font-display font-semibold ${s.textColor} tracking-wider uppercase`}>
                  Visit Profile →
                </span>
              </div>
            </motion.a>
          ))}
        </div>
      </div>
    </section>
  );
}
