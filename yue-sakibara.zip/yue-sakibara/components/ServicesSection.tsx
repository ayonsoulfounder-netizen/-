"use client";

import { useRef } from "react";
import { motion, useInView } from "framer-motion";
import { Gem, Smartphone, Monitor, Package, Send, MessageCircle, ExternalLink } from "lucide-react";

const services = [
  { icon: Gem, label: "Aplikasi Premium", desc: "Akses aplikasi premium dengan harga terjangkau", color: "text-kawaii-pink" },
  { icon: Smartphone, label: "Nokos Berbagai Negara", desc: "Nomor virtual dari berbagai negara tersedia", color: "text-kawaii-blue" },
  { icon: Monitor, label: "Panel Pterodactyl", desc: "Hosting game server berbasis Pterodactyl", color: "text-kawaii-mint" },
  { icon: Package, label: "Hollow APK", desc: "APK modifikasi & customization berbasis kebutuhan", color: "text-kawaii-peach" },
];

const fadeUp = {
  hidden: { opacity: 0, y: 30 },
  visible: (i: number) => ({
    opacity: 1,
    y: 0,
    transition: { duration: 0.6, delay: i * 0.1, ease: [0.22, 1, 0.36, 1] },
  }),
};

export default function ServicesSection() {
  const ref = useRef<HTMLElement>(null);
  const inView = useInView(ref, { once: true, margin: "-80px" });

  return (
    <section id="services" ref={ref} className="relative py-24 px-4 overflow-hidden">
      {/* Glow */}
      <div className="absolute top-1/3 right-0 w-[400px] h-[400px] bg-kawaii-blue/5 blur-[120px] pointer-events-none" />

      <div className="max-w-6xl mx-auto">
        {/* Section label */}
        <motion.div
          custom={0} variants={fadeUp} initial="hidden" animate={inView ? "visible" : "hidden"}
          className="flex items-center gap-3 mb-12"
        >
          <span className="text-kawaii-blue text-sm font-display font-semibold tracking-widest uppercase">
            02 / Services
          </span>
          <div className="flex-1 h-px bg-kawaii-blue/20" />
        </motion.div>

        {/* Main card */}
        <motion.div
          custom={1} variants={fadeUp} initial="hidden" animate={inView ? "visible" : "hidden"}
          className="neo-card-blue p-6 md:p-8 mb-8"
        >
          <div className="mb-6">
            <h2 className="font-display font-bold text-2xl md:text-3xl text-white mb-2">
              🛒 ⸸ <span className="gradient-blue">𝑨𝒍𝒍 𝑰𝒏𝒇𝒐𝒓𝒎𝒂𝒕𝒊𝒐𝒏 𝑨𝒏𝒅 𝑻𝒆𝒔𝒕𝒊𝒎𝒐𝒏𝒊</span> ⸸
            </h2>
            <p className="text-white/50 font-body text-sm tracking-wide">
              Premium Apps • Nokos 🌎 • Pterodactyl Panel • Hollow APK
            </p>
          </div>

          <p className="text-white/65 font-body mb-6 leading-relaxed">
            Temukan layanan digital terbaik dengan kualitas premium. Semua layanan telah terverifikasi
            dan didukung oleh ribuan testimonial dari pelanggan yang puas. Dapatkan akses ke produk
            eksklusif dengan harga yang kompetitif.
          </p>

          {/* Service cards grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-8">
            {services.map((s, i) => (
              <motion.div
                key={s.label}
                custom={i + 2} variants={fadeUp} initial="hidden" animate={inView ? "visible" : "hidden"}
                whileHover={{ x: -2, y: -2 }}
                className="flex items-start gap-3 p-4 bg-white/3 border border-white/8 hover:border-kawaii-blue/30 transition-all duration-200 group"
              >
                <div className="p-2 bg-white/5 shrink-0 group-hover:bg-kawaii-blue/10 transition-colors">
                  <s.icon className={`w-5 h-5 ${s.color}`} />
                </div>
                <div>
                  <p className="font-display font-semibold text-white text-sm">{s.label}</p>
                  <p className="text-white/50 text-xs font-body mt-0.5">{s.desc}</p>
                </div>
              </motion.div>
            ))}
          </div>

          {/* Contact info */}
          <div className="border-t border-white/10 pt-6 mb-6">
            <p className="text-xs font-display font-semibold text-white/40 tracking-widest uppercase mb-4">
              Informasi Kontak
            </p>
            <div className="space-y-3">
              <div className="flex items-center gap-3">
                <span className="text-lg">📢</span>
                <div>
                  <span className="text-white/50 text-xs font-body">Channel Telegram</span>
                  <p className="text-kawaii-blue font-display font-semibold text-sm">@yuechh</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <span className="text-lg">👤</span>
                <div>
                  <span className="text-white/50 text-xs font-body">Owner / Admin</span>
                  <p className="text-kawaii-pink font-display font-semibold text-sm">@yueech</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <span className="text-lg">📢</span>
                <div>
                  <span className="text-white/50 text-xs font-body">WhatsApp Channel</span>
                  <a
                    href="https://whatsapp.com/channel/0029VbDdYidGk1G1lWlbKK2A"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-kawaii-mint font-display font-semibold text-sm flex items-center gap-1 hover:opacity-80 transition-opacity"
                  >
                    Klik untuk bergabung
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
              </div>
            </div>
          </div>

          {/* CTA buttons */}
          <div className="flex flex-wrap gap-3">
            <motion.a
              href="https://t.me/yuechh"
              target="_blank"
              rel="noopener noreferrer"
              whileHover={{ scale: 1.03, y: -2 }}
              whileTap={{ scale: 0.97 }}
              className="btn-solid-blue flex items-center gap-2 text-sm"
            >
              <Send className="w-4 h-4" />
              Join Telegram Channel
            </motion.a>
            <motion.a
              href="https://whatsapp.com/channel/0029VbDdYidGk1G1lWlbKK2A"
              target="_blank"
              rel="noopener noreferrer"
              whileHover={{ scale: 1.03, y: -2 }}
              whileTap={{ scale: 0.97 }}
              className="btn-neo border-kawaii-mint text-kawaii-mint shadow-neo-mint hover:bg-kawaii-mint/10 flex items-center gap-2 text-sm hover:translate-x-[-2px] hover:translate-y-[-2px] hover:shadow-[6px_6px_0px_rgba(184,240,223,0.6)] transition-all duration-150"
            >
              <MessageCircle className="w-4 h-4" />
              Join WhatsApp Channel
            </motion.a>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
