import Navbar from "@/components/Navbar";
import HeroSection from "@/components/HeroSection";
import AboutSection from "@/components/AboutSection";
import ServicesSection from "@/components/ServicesSection";
import SocialSection from "@/components/SocialSection";
import PaymentSection from "@/components/PaymentSection";
import StatsSection from "@/components/StatsSection";
import Footer from "@/components/Footer";

export default function Home() {
  return (
    <main className="relative">
      <Navbar />
      <HeroSection />
      <AboutSection />
      <ServicesSection />
      <SocialSection />
      <PaymentSection />
      <StatsSection />
      <Footer />
    </main>
  );
}
