import type { Metadata } from "next";
import { Space_Grotesk, Inter } from "next/font/google";
import "./globals.css";

const spaceGrotesk = Space_Grotesk({
  subsets: ["latin"],
  variable: "--font-display",
  weight: ["400", "500", "600", "700"],
  display: "swap",
});

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-body",
  display: "swap",
});

export const metadata: Metadata = {
  title: "Yue Sakibara | Developer & Designer",
  description:
    "Portfolio of Yue Sakibara — Developer, Designer & Creator. Specializing in web development, UI/UX, automation, bot development, server management, and modern application development.",
  keywords: [
    "Yue Sakibara",
    "developer",
    "web development",
    "UI/UX",
    "Next.js",
    "TypeScript",
    "Pterodactyl",
    "Automation",
  ],
  authors: [{ name: "Yue Sakibara", url: "https://t.me/yueech" }],
  creator: "Yue Sakibara",
  metadataBase: new URL("https://yue-sakibara.vercel.app"),
  openGraph: {
    title: "Yue Sakibara | Developer & Designer",
    description:
      "Personal portfolio of Yue Sakibara — Developer, Designer & Creator.",
    type: "website",
    locale: "id_ID",
    siteName: "Yue Sakibara",
  },
  twitter: {
    card: "summary_large_image",
    title: "Yue Sakibara | Developer & Designer",
    description: "Personal portfolio of Yue Sakibara — Developer, Designer & Creator.",
  },
  robots: {
    index: true,
    follow: true,
    googleBot: { index: true, follow: true },
  },
  viewport: {
    width: "device-width",
    initialScale: 1,
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html
      lang="id"
      className={`${spaceGrotesk.variable} ${inter.variable} scroll-smooth`}
      suppressHydrationWarning
    >
      <body className="font-body bg-base text-white antialiased overflow-x-hidden">
        {children}
      </body>
    </html>
  );
}
